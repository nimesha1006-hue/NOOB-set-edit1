NOOB SetEdit - Android project

මෙය source project එකකි; APK ගොනුවක් නොවේ.

Build කරන ආකාරය:
1. Android Studio ස්ථාපනය කර project folder එක open කරන්න.
2. Gradle sync සම්පූර්ණ වීමට ඉඩ දෙන්න.
3. Build > Build APK(s) තෝරන්න.
4. APK එක app/build/outputs/apk/debug/app-debug.apk යටතේ ලැබේ.

Minimum Android: 9 (API 28)
මෙම app එක ආරක්ෂිත මාර්ගෝපදේශයක් පමණි. System settings හෝ Free Fire files වෙනස් නොකරයි.

APK එක GitHub Actions හරහා හදාගන්න:
1. මේ project එකේ සියලුම files GitHub repository එකේ main branch එකට upload/commit කරන්න.
2. Repository එකේ Actions tab එකට යන්න.
3. "Build NOOB SetEdit APK" workflow එක තෝරලා run workflow කරන්න (නැත්නම් push කළාම ස්වයංක්‍රීයව run වෙයි).
4. Build එක සාර්ථක වුණාම workflow run එක පහළ Artifacts යටතේ NOOB-SetEdit-debug-apk download කරන්න.
5. ZIP එක extract කර app-debug.apk එක Android phone එකට download කර install කරන්න. Android settings වලින් මේ file manager/browser එකට install unknown apps අවසරය දීමට සිදු විය හැක.
සටහන: මේ APK එකේ සාමාන්‍ය උපදෙස් පෙන්වන app එකක් පමණයි; Android system settings හෝ Free Fire game files වෙනස් කරන්නේ නැහැ. Build සාර්ථක වීම තවම පරීක්ෂා කර නැත.
