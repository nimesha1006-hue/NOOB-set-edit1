package com.noob.setedit

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(18, 28, 45)
    private val green = Color.rgb(22, 163, 74)

    private fun addText(parent: LinearLayout, message: String, size: Float) {
        val text = TextView(this).apply {
            this.text = message
            textSize = size
            setTextColor(Color.WHITE)
            setPadding(0, 10, 0, 10)
        }
        parent.addView(text, ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(bg)
        }

        addText(content, "NOOB SetEdit", 28f)
        addText(content, "OPPO A1K • Android 9 • 2GB RAM", 15f)
        addText(content, "SAFE GAME GUIDE", 13f)

        val optimize = Button(this).apply {
            text = "Game එකට පෙර සූදානම් වෙන්න"
            setOnClickListener {
                Toast.makeText(
                    this@MainActivity,
                    "අනවශ්‍ය apps වසා, phone එක සිසිල්ව තබා game එක විවෘත කරන්න.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
        content.addView(optimize)

        addText(content, "Free Fire Graphics", 21f)
        addText(content,
            "• Graphics: Smooth\n" +
            "• High FPS: ස්ථාවරව වැඩ කරන විකල්පය\n" +
            "• Shadows: තිබේ නම් Off\n" +
            "• Phone එක රත් වුණොත් විවේකයක් දෙන්න.", 16f)

        addText(content, "Sensitivity Guide", 21f)
        addText(content,
            "මෙම අගයන් slider එක 0–200 නම් පමණක් උත්සාහ කරන්න:\n\n" +
            "General: 185\nRed Dot: 175\n2× Scope: 160\n" +
            "4× Scope: 145\nSniper Scope: 90\nFree Look: 120\n\n" +
            "මේවා ආරම්භක අගයන් පමණයි. Training Ground එකේ පරීක්ෂා කරන්න.", 16f)

        addText(content, "Phone Optimization", 21f)
        addText(content,
            "• Game එකට පෙර අනවශ්‍ය apps වසා දමන්න.\n" +
            "• Free Fire cache පමණක් ඉවත් කරන්න; Clear Data එපා.\n" +
            "• Storage ඉඩ තබාගන්න.\n" +
            "• Battery saver නිසා performance අඩුවෙනවාද පරීක්ෂා කරන්න.", 16f)

        addText(content, "Safety", 21f)
        addText(content,
            "මෙම app එක system settings හෝ game files වෙනස් කරන්නේ නැහැ. " +
            "Root අවශ්‍ය නැහැ. FPS වැඩිවීමක් හෝ account ban නොවන බවට සහතිකයක් දෙන්නේ නැහැ.", 16f)

        val scroll = ScrollView(this).apply { addView(content) }
        setContentView(scroll)
    }
}
